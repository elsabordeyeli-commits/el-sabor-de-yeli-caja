# El sabor de Yeli · Sistema de caja

Sistema de facturación para negocio de comida: ventas, cuentas por mesa, caja, créditos (fiados), compras, inventario, resumen, ganancias, fondo y usuarios con roles.

## Estructura

```
yeli-caja/
├── index.html    ← toda la aplicación (incluye el logo)
├── vercel.json   ← configuración de Vercel
├── .gitignore
└── README.md
```

## Usuarios de prueba (¡cámbialos!)

| Usuario | Contraseña | Rol |
|---|---|---|
| presidente | dueno123 | Presidente (dueño) |
| admin | admin123 | Administrador |
| vendedor | vende123 | Vendedor |

Entra como `presidente`, ve a **Usuarios** y cambia las contraseñas antes de usarlo con clientes.

## Subir a GitHub

1. Crea una cuenta en https://github.com y pulsa **New repository** (nombre: `yeli-caja`).
2. Pulsa **uploading an existing file** y arrastra el contenido de esta carpeta (index.html, vercel.json, .gitignore, README.md).
3. Pulsa **Commit changes**.

O por terminal:

```bash
cd yeli-caja
git init
git add .
git commit -m "Primera versión"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/yeli-caja.git
git push -u origin main
```

## Publicar en Vercel

1. Entra a https://vercel.com e inicia sesión con tu cuenta de GitHub.
2. **Add New → Project** y elige el repositorio `yeli-caja`.
3. Framework Preset: **Other**. No hay build command ni output directory.
4. Pulsa **Deploy**. En menos de un minuto tendrás un enlace como `https://yeli-caja.vercel.app`.

Cada cambio que subas a GitHub se publica solo.

## Dominio propio (opcional)

En Vercel: **Project → Settings → Domains** y agrega tu dominio.

## Importante: dónde se guardan los datos

Esta versión guarda la información en el navegador de cada dispositivo (localStorage). Eso significa:

- Cada celular o computadora tiene sus propios datos.
- El bloqueo de usuarios solo funciona en el dispositivo donde se hace.
- Si se borra el navegador, se pierden los datos.

Para que varios dispositivos compartan los mismos datos y el bloqueo valga en todos, el siguiente paso es agregar una base de datos (por ejemplo Supabase o Vercel Postgres) y un inicio de sesión real en servidor.
